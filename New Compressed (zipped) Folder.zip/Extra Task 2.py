from statistics import mean
rainPerMonth = []
rain = []
for x in range(0, 12):
    rainLevel = input("enter rainfall level")
    if x == 0:
        month = "Jan"
    elif x == 1:
        month = "Feb"
    elif x == 2:
        month = "Mar"
    elif x == 3:
        month = "Apr"
    elif x == 4:
        month = "May"
    elif x == 5:
        month = "Jun"
    elif x == 6:
        month = "Jul"
    elif x == 7:
        month = "Aug"
    elif x == 8:
        month = "Sep"
    elif x == 9:
        month = "Oct"
    elif x == 10:
        month = "Nov"
    elif x == 11:
        month = "Dec"

    rainPerMonth.append(month + " = " + rainLevel +"mm")
    rain.append(rainLevel)

maxVal = max(rain)
minVal = min(rain)
avgVal = mean(rain)

print("Average =", AvgVal, "\n Maxrainfall:", maxVal, rainPerMonth[rain.index(int(maxVal))])
