import random
deck = []
for x in range(2, 11):
    CardNum = str(x)
    deck.append(CardNum + " of Spades")
    deck.append(CardNum + " of Hearts")
    deck.append(CardNum + " of Diamonds")
    deck.append(CardNum + " of Clubs")

for x in range(0, 4):
    if x == 0:
        CardNum = "Ace"
    elif x == 1:
        CardNum = "Queen"
    elif x == 2:
        CardNum = "King"
    elif x == 1:
        CardNum = "Jack"

    deck.append(CardNum + " of Spades")
    deck.append(CardNum + " of Hearts")
    deck.append(CardNum + " of Diamonds")
    deck.append(CardNum + " of Clubs")


random.shuffle(deck)

N = deck[:13]
E = deck[13:26]
S = deck[26:39]
W = deck[39:]

if "Ace of Spades" in N:
    print("N has the ace of spades")
elif "Ace of Spades" in E:
    print("E has the ace of spades")
elif "Ace of Spades" in S:
    print("S has the ace of spades")
elif "Ace of Spades" in W:
    print("W has the ace of spades")

