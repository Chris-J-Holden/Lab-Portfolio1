password = "1243"
inputPass = input("enter the secret password: ")
while inputPass != password:
    print("INCORRECT")
    inputPass = input("enter the secret password: ")
print("correct, you may enter")