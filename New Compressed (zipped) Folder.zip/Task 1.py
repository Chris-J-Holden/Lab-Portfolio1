name = input("Greetings! How shall we call you?: ")

if name[:4] == "Lord" or "Lady":
    print("It shall be so,", name)

