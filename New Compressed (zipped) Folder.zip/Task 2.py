spam = input("how much spam would you like?: ")

spamNum = "spam, "*(int(spam)-1)
if spam == "0":
    print("one order of egg")
else:
    print("one order of egg with", spamNum + "and spam please")
